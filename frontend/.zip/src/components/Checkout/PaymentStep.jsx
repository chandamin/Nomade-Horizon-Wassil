// export default function PaymentStep() {
//   return (
//     <div>
//       <div className="nr-fir-st-hed-wr">
//         <span className="nr-check-count">3</span>
//         <p className="nr-first-st-hed">Payment</p>
//       </div>

//       <button className="nr-button-payment">
//         Place an order
//       </button>
//     </div>
//   );
// }
export default function PaymentStep() {
  return (
    <section className="pb-4">
      {/* HEADER */}
      <h2 className="flex items-center gap-2 text-sm font-semibold text-gray-900 mb-3">
        <span className="flex items-center justify-center w-6 h-6 rounded-full border text-xs">
          3
        </span>
        Payment
      </h2>

      {/* PAYMENT METHOD BOX */}
      <div className="border rounded p-4 bg-white">
        {/* METHOD SELECT */}
        <label className="flex items-center gap-2 text-sm font-medium mb-4">
          <input
            type="radio"
            name="payment"
            defaultChecked
          />
          Map
        </label>

        {/* CARD FORM */}
        <div className="grid grid-cols-2 gap-4">
          {/* CARD NUMBER */}
          <div className="col-span-2">
            <label className="block text-xs text-gray-600 mb-1">
              Card number
            </label>
            <div className="relative">
              <input
                type="text"
                placeholder="1234 1234 1234 1234"
                className="w-full border rounded px-3 py-2 pr-24 text-sm"
              />
              <div className="absolute right-2 top-2 flex gap-1">
                <img src="/visa.svg" alt="Visa" className="h-4" />
                <img src="/mc.svg" alt="Mastercard" className="h-4" />
                <img src="/amex.svg" alt="Amex" className="h-4" />
              </div>
            </div>
          </div>

          {/* EXPIRY */}
          <div>
            <label className="block text-xs text-gray-600 mb-1">
              Expiration date
            </label>
            <input
              type="text"
              placeholder="MM / YY"
              className="w-full border rounded px-3 py-2 text-sm"
            />
          </div>

          {/* CVC */}
          <div>
            <label className="block text-xs text-gray-600 mb-1">
              Security code
            </label>
            <input
              type="text"
              placeholder="CVC"
              className="w-full border rounded px-3 py-2 text-sm"
            />
          </div>
        </div>

        {/* SECURITY NOTE */}
        <div className="flex items-center gap-2 mt-3 text-xs text-gray-600">
          🔒 Paiement sécurisé – Vos informations sont 100% confidentielles.
        </div>
      </div>
    </section>
  );
}

