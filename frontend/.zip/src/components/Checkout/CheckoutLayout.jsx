// import { useState } from 'react';
// import ClientStep from './ClientStep';
// import ShippingStep from './ShippingStep';
// import PaymentStep from './PaymentStep';
// import OrderSummary from './OrderSummary';

// export default function CheckoutLayout() {
//   const [step, setStep] = useState(1);

//   return (
//     <div className="nr-checkout-main">
//       <div className="container nr-checkout-flx-wr">
//         <div className="nr-lft-prt">
//           { <ClientStep onNext={() => setStep(2)} />}
//           {<ShippingStep onNext={() => setStep(3)} />}
//           { <PaymentStep />}
//         </div>

//         <div className="nr-rght-prt">
//           <OrderSummary />
//         </div>
//       </div>
//     </div>
//   );
// }

import { useState } from "react";
import ClientStep from "./ClientStep";
import ShippingStep from "./ShippingStep";
import PaymentStep from "./PaymentStep";
import OrderSummary from "./OrderSummary";

export default function CheckoutLayout() {
  /**
   * activeStep controls which section is expanded.
   * Order: client → delivery → payment
   */
  const [activeStep, setActiveStep] = useState("client");

  /**
   * Static state holders for now
   * (will be hydrated later via BigCommerce SDK)
   */
  const [clientData, setClientData] = useState(null);
  const [deliveryData, setDeliveryData] = useState(null);

  return (
    <div className="min-h-screen bg-[#f5f5f5]">
      {/* ================= HEADER ================= */}
      <header className="bg-white border-b">
        <div className="max-w-[1180px] mx-auto py-4 text-center">
          <img
            src="https://images.unsplash.com/photo-1607082349566-1870e33f43d1?w=200"
            alt="Flashventes"
            className="h-7 mx-auto object-contain"
          />
        </div>
      </header>

      {/* ================= PROMO BANNER ================= */}
      <div className="bg-[#3f4a59] text-white text-xs">
        <div className="max-w-[1180px] mx-auto py-2 text-center">
          <span className="font-semibold">
            Congratulations, your discount has been applied.
          </span>
          <span className="ml-1">
            You have <strong>03:55</strong> left to take advantage of this offer.
            Valid on <strong>28/01/2026</strong>
          </span>
        </div>
      </div>

      {/* ================= MAIN CONTENT ================= */}
      <main className="max-w-[1180px] mx-auto grid grid-cols-12 gap-8 py-8">
        {/* ================= LEFT COLUMN ================= */}
        <section className="col-span-7">
          <div className="bg-white border rounded p-6 space-y-6">
            {/* CLIENT STEP */}
            <ClientStep
              active={activeStep === "client"}
              data={clientData}
              onContinue={(data) => {
                setClientData(data);
                setActiveStep("delivery");
              }}
              onEdit={() => setActiveStep("client")}
            />

            {/* DELIVERY STEP */}
            <ShippingStep
              active={activeStep === "delivery"}
              data={deliveryData}
              onContinue={(data) => {
                setDeliveryData(data);
                setActiveStep("payment");
              }}
              onEdit={() => setActiveStep("delivery")}
            />

            {/* PAYMENT STEP */}
            <PaymentStep active={activeStep === "payment"} />

            {/* PLACE ORDER (VISIBLE ONLY ON PAYMENT) */}
            {activeStep === "payment" && (
              <>
                <button
                  type="button"
                  className="w-full bg-[#2fb34a] hover:bg-[#28a745] transition text-white font-semibold py-3 rounded"
                >
                  PLACE AN ORDER
                </button>

                {/* SECURITY TEXT */}
                <div className="text-xs text-gray-600 text-center mt-3">
                  🔒 Secure 256-bit SSL encryption
                </div>

                {/* TRUST BADGES */}
                <div className="flex justify-center gap-6 mt-4">
                  <img
                    src="https://upload.wikimedia.org/wikipedia/commons/3/3a/McAfee_logo.png"
                    alt="McAfee"
                    className="h-6"
                  />
                  <img
                    src="https://upload.wikimedia.org/wikipedia/commons/6/6b/Norton_logo.svg"
                    alt="Norton"
                    className="h-6"
                  />
                  <img
                    src="https://upload.wikimedia.org/wikipedia/commons/5/5b/TRUSTe_logo.png"
                    alt="TRUSTe"
                    className="h-6"
                  />
                </div>
              </>
            )}
          </div>
        </section>

        {/* ================= RIGHT COLUMN ================= */}
        <aside className="col-span-5">
          <OrderSummary deliveryPrice={deliveryData?.price ?? 0} />
        </aside>
      </main>

      {/* ================= FOOTER ================= */}
      <footer className="text-xs text-gray-500 text-center py-6 space-y-2">
        <div className="space-x-3">
          <a href="#" className="hover:underline">
            General Terms and Conditions
          </a>
          <a href="#" className="hover:underline">
            Shipping Policies and Rates
          </a>
          <a href="#" className="hover:underline">
            Privacy Policy
          </a>
        </div>
        <div>
          <a href="#" className="hover:underline">
            Exchanges and Returns
          </a>
        </div>
      </footer>
    </div>
  );
}


// import ClientStep from "./ClientStep";
// import ShippingStep from "./ShippingStep";
// import PaymentStep from "./PaymentStep";
// import OrderSummary from "./OrderSummary";

// export default function CheckoutLayout() {
//   return (
//     <div className="min-h-screen bg-gray-100">
//       {/* Discount banner */}
//       <div className="bg-slate-700 text-white text-sm py-2 px-4 text-center">
//         <strong>Congratulations, your discount has been applied.</strong>
//         <span className="ml-2">
//           You have <strong>04:36</strong> left to take advantage of this offer.
//           Valid on <strong>22/01/2026</strong>
//         </span>
//       </div>

//       <div className="max-w-6xl mx-auto grid grid-cols-12 gap-6 py-8">
//         {/* Left: Checkout steps */}
//         <div className="col-span-8 bg-white rounded shadow-sm p-6">
//           <ClientStep />
//           <ShippingStep />
//           <PaymentStep />
//         </div>

//         {/* Right: Order summary */}
//         <div className="col-span-4">
//           <OrderSummary />
//         </div>
//       </div>
//     </div>
//   );
// }
