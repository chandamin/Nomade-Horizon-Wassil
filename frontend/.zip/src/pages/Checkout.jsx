// import CheckoutLayout from '../components/Checkout/CheckoutLayout';
// import '../styles/checkout.css';

// export default function Checkout() {
//   return <CheckoutLayout />;
// }

import CheckoutLayout from "../components/Checkout/CheckoutLayout";

export default function Checkout() {
  return <CheckoutLayout />;
}
